import hashlib


def checks(email, password):
    password = hashlib.sha256(password.encode()).hexdigest()
    email = hashlib.sha256(email.encode()).hexdigest()

    with open("users.txt", "r") as f:
        for line in f.readlines():
            data = line.strip().split(":")

            # Ensure the data list has at least 3 elements (username, email hash, password hash)
            if len(data) < 3:
                continue

            if email == data[1]:
                print("T (Email matched)")
                if password == data[2]:
                    print("T (Password matched)")
                    return True
                else:
                    print("F (Password didn't match)")
            else:
                print("F (Email didn't match)")

            print("email (hashed): " + email)
            print("data[1] (hashed email from file): " + data[1])

    return False


def create_user(user_name, email, password):
    with open("users.txt", "r") as f:
        current_data = f.read().strip()
    balance = 0
    new_user = f"{user_name}:{hashlib.sha256(email.encode()).hexdigest()}:{hashlib.sha256(password.encode()).hexdigest()}:{balance}"

    with open("users.txt", "a") as f:
        # Add a newline if the file isn't empty
        if current_data:
            f.write("\n")
        f.write(new_user)


def get_balance(email, password):
    password = hashlib.sha256(password.encode()).hexdigest()
    email = hashlib.sha256(email.encode()).hexdigest()
    with open("users.txt", "r") as f:
        for line in f.readlines():
            data = line.strip().split(":")

            # Ensure the data list has at least 3 elements (username, email hash, password hash)
            if len(data) < 3:
                continue

            if email == data[1]:
                print("T (Email matched)")
                if password == data[2]:
                    print("T (Password matched)")
                    return int(data[3])
                else:
                    print("F (Password didn't match)")
            else:
                print("F (Email didn't match)")

            print("email (hashed): " + email)
            print("data[1] (hashed email from file): " + data[1])


def set_balance(email, password, balance):
    password = hashlib.sha256(password.encode()).hexdigest()
    email = hashlib.sha256(email.encode()).hexdigest()

    with open("users.txt", "r") as f:
        for line in f.readlines():
            data = line.strip().split(":")

            # Ensure the data list has at least 3 elements (username, email hash, password hash)
            if len(data) < 3:
                continue

            if email == data[1]:
                print("T (Email matched)")
                if password == data[2]:
                    print("T (Password matched)")

                    with open("yourfile.txt", "r") as F:
                        lines = F.readlines()
                    with open("yourfile.txt", "w") as F:
                        for line in lines:
                            if line.strip("\n") != "nickname_to_delete":
                                F.write(line)


                    return True

                else:
                    print("F (Password didn't match)")
            else:
                print("F (Email didn't match)")

            print("email (hashed): " + email)
            print("data[1] (hashed email from file): " + data[1])

    return False