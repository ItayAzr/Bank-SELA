from tkinter import *
from login_page import login_page_func
from register_page import register_page_func
import exemple
import Shape


def window():
    window = Tk()

    height = 650
    width = 1240
    x = (window.winfo_screenwidth() // 2) - (width // 2)
    y = (window.winfo_screenheight() // 4) - (height // 4)
    window.geometry('{}x{}+{}+{}'.format(width, height, x, y))

    window.configure(bg="#525561")
    while True:
        login_page_func(window)
        register_page_func(window)



window()