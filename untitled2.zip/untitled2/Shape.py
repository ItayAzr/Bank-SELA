import tkinter as tk
from tkinter import *
from tkinter import messagebox
from tkinter import ttk


# Main Application Class
class MoneyApp:
    def __init__(self, root):
        self.root = root

        height = 650
        width = 1240
        x = (root.winfo_screenwidth() // 2) - (width // 2)
        y = (root.winfo_screenheight() // 4) - (height // 4)
        root.geometry('{}x{}+{}+{}'.format(width, height, x, y))

        root.configure(bg="#525561")

        # ================Background Image ====================
        backgroundImage = PhotoImage(file="assets\\image_1.png")
        bg_image = Label(
            root,
            image=backgroundImage,
            bg="#525561"
        )
        bg_image.place(x=120, y=28)

        self.balance = 0  # Initial balance set to zero

        # ================ Title Label ====================
        Login_headerText1 = Label(
            text="Bank SELA",
            fg="#FFFFFF",
            font=("yu gothic ui bold", 40 * -1),
            bg="#272A37"
        )
        Login_headerText1.place(x=500, y=125)

        # Balance display
        self.balance_label = tk.Label(self.root, text=f"Balance: ${self.balance:.2f}",  fg="#FFFFFF", font=("yu gothic ui bold", 20 * -1),  bg="#272A37" )
        self.balance_label.place(x=530, y=300)

        # Amount Entry label
        self.amount_label = tk.Label(self.root, text="Enter Amount:",  fg="#FFFFFF", font=("yu gothic ui bold", 20 * -1),  bg="#272A37")
        self.amount_label.place(x=400, y=400)

        # Amount Entry field with rounded corners and subtle shadow
        self.amount_entry = tk.Entry(self.root, font=("Arial", 12), width=20, borderwidth=2, relief="flat",
                                     bg="#FFFFFF", highlightbackground="#ddd", highlightthickness=1)
        self.amount_entry.place(x=550, y=410)

        # Give Money Button
        self.give_button = tk.Button(self.root, text="Withdraw",  fg="#FFFFFF", font=("yu gothic ui bold", 20 * -1),  bg="#33BB00",
                                     command=self.give_money, relief="flat", height=2, width=15)
        self.give_button.place(x=400, y=500)
        self.give_button.bind("<Enter>", self.on_enter)
        self.give_button.bind("<Leave>", self.on_leave)
        self.give_button.bind("<Button-1>", self.on_click)

        # Receive Money Button
        self.receive_button = tk.Button(self.root, text="Deposit", fg="#FFFFFF", font=("yu gothic ui bold", 20 * -1), bg="#3300BB",
                                        command=self.receive_money, relief="flat", height=2, width=15)
        self.receive_button.place(x=700, y=500)
        self.receive_button.bind("<Enter>", self.on_enter)
        self.receive_button.bind("<Leave>", self.on_leave)
        self.receive_button.bind("<Button-1>", self.on_click)

        # Exit Button
        self.exit_button = tk.Button(self.root, text="Exit", font=("yu gothic ui bold", 20 * -1), fg="white", bg="#FF0000",
                                     command=exit, relief="flat")
        self.exit_button.place(x=150, y=90, height=25, width=115)
        self.exit_button.bind("<Enter>", self.on_enter)
        self.exit_button.bind("<Leave>", self.on_leave)
        self.exit_button.bind("<Button-1>", self.on_click)

        self.root.mainloop()

    def update_balance(self):
        # Update the balance label
        self.balance_label.config(text=f"Balance: ${self.balance:.2f}")

    def give_money(self):
        try:
            amount = float(self.amount_entry.get())
            if amount <= 0:
                messagebox.showerror("Invalid Amount", "Amount to give must be positive!")
                return
            if amount > self.balance:
                messagebox.showerror("Insufficient Funds", "You do not have enough balance!")
                return
            self.balance -= amount
            self.update_balance()
            messagebox.showinfo("Transaction Successful", f"You have successfully given ${amount}.")
            self.amount_entry.delete(0, tk.END)
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter a valid number!")

    def receive_money(self):
        try:
            amount = float(self.amount_entry.get())
            if amount <= 0:
                messagebox.showerror("Invalid Amount", "Amount to receive must be positive!")
                return
            self.balance += amount
            self.update_balance()
            messagebox.showinfo("Transaction Successful", f"You have successfully received ${amount}.")
            self.amount_entry.delete(0, tk.END)
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter a valid number!")

    def on_enter(self, event):
        # Change button color on hover
        event.widget.config(bg="#3E3E3E")

    def on_leave(self, event):
        # Restore button color when not hovering
        if event.widget == self.give_button:
            event.widget.config(bg="#33BB00")
        elif event.widget == self.receive_button:
            event.widget.config(bg="#3300BB")
        elif event.widget == self.exit_button:
            event.widget.config(bg="#FF0000")

    def on_click(self, event):
        # Change button color on click (active state)
        event.widget.config(bg="#2E2E2E")


def play(window, email, password):

    app = MoneyApp(window)




